#!/usr/bin/env bash
# regress.sh - every simulation test of the repository, in one go.
#
#   scripts/regress.sh            (from the repository root)
#
# Steps: Go unit tests, Icarus UART/NTT/UART-link benches, Icarus unit
# tests of keccak_sponge (vs hashlib), modmul (exhaustive) / pack / unpack, cocotb Barrett
# (Icarus) and Keccak-f1600 (Verilator) tests if cocotb-config is on PATH,
# the TVLA Verilator model build, and the ML-KEM-768 ACVP vectors on the full core (scripts/sim_acvp.py).
# Exits non-zero on the first failure.
set -euo pipefail
cd "$(dirname "$0")/.."

step() { printf '\n=== %s\n' "$*"; }

step "go test"
go test ./... -race -count=1 | grep -v "no test files"

step "iverilog: uart, ntt, uart-link"
make -s -C testbench/iverilog all | grep -E "PASS|FAIL"
make -s -C testbench/iverilog uart-link BAUD=1000000 | grep -E "PASS|FAIL"

step "iverilog: keccak_sponge vs hashlib"
make -s -C testbench/sponge 2>&1 | grep -E "^TB_|^tb_|block"
grep -q PASS build/sponge/tb_sponge.log

step "iverilog units: modmul (exhaustive), pack, unpack, banked FIFO"
make -s -C testbench/units all 2>&1 | grep -E "^TB_|^tb_"
grep -q PASS build/units/tb_modmul.log && grep -q PASS build/units/tb_pack.log && grep -q PASS build/units/tb_unpack.log && grep -q PASS build/units/tb_word_fifo.log

if command -v cocotb-config >/dev/null; then
    step "cocotb: Barrett (icarus), Keccak-f1600 (verilator)"
    make -s -C testbench/ntt SIM=icarus 2>&1 | grep -E "TESTS="
    make -s -C testbench/keccak SIM=verilator 2>&1 | grep -E "TESTS="
    if grep -q '<failure' testbench/ntt/results.xml testbench/keccak/results.xml; then exit 1; fi
else
    step "cocotb: SKIPPED (cocotb-config not on PATH)"
fi

step "tvla_sim: Verilator model builds"
make -s -C testbench/tvla_sim >/dev/null && echo "TVLA_SIM BUILD PASS"

step "axil_cdc system test: 100 MHz master -> 206 MHz core (Verilator)"
make -s -C testbench/cdc 2>&1 | grep -E "^TB_CDC|cycles"
grep -q PASS build/cdc/tb_cdc.log

step "ACVP ML-KEM-768 on the core (Verilator)"
python3 scripts/sim_acvp.py

step "REGRESS PASS"
